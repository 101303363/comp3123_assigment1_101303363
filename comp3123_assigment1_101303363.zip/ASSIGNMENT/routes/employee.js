const express =require("express")
const routes = express.Router()
const { find } = require("../models/user_db")
// const { model } = require("mongoose")
// Comes From Model of the user_db //
const emplooyeModel = require("../models/employee_db")
const { json } = require("express")

   

 // Display all employee Information // 
routes.get("/emp/employees",async(req,res)=>{
    try {
        const get_all_employee =await emplooyeModel.find({})
        // res.status(201).json({message:"we got some records"}).send(get_all_employee)
         res.status(201).send(get_all_employee)


    } catch (error) {
        res.status(500).send({message: "No Employee recorded", error})

    }
})


// ADD Employee //
routes.post("/emp/employees",async(req,res)=>{
    const new_employe=emplooyeModel(req.body)
    const {first_name,last_name,email,gender,salary} =req.body
    try {
        const save_employee= await new_employe.save()
        res.status(201).json({message:"Succesfully added of employee"}).send(save_employee)

    } catch (error) {
        res.status(500).send({message:"inserting issue please try again"})

    }

   
})

// Get by id //
routes.get("/emp/employees/:eid",async(req,res)=>{
    const id =req.params.eid ;
    const get_id_employee =await emplooyeModel.findById(id)
    try {
        res.status(200).json(get_id_employee)
    } catch (error) {
        res.status(500).send({message:"Update  issue please try again"})

    }

    // res.send("Welcome Employees - GET - eid")
})

// Update
routes.put("/emp/employees/:eid",async(req,res)=>{
    const id =req.params.eid ;
    const get_id_employee =await emplooyeModel.findById(id)
    const {first_name,last_name,email,gender,salary} =req.body
    try {
       
        const save_employee= await get_id_employee.save()
        res.status(200).json(save_employee)

    } catch (error) {
        res.status(500).send({message:"inserting issue please try again"})

    }

})


// Delete //

routes.delete("/emp/employees/:eid",async(req,res)=>{
    const id =req.params.eid ;
    const get_id_employee =await emplooyeModel.findByIdAndDelete(id)
    try {
        res.status(200).json(get_id_employee)
    } catch (error) {
        res.status(500).send({message:"Update  issue please try again"})

    
}})








module.exports=routes