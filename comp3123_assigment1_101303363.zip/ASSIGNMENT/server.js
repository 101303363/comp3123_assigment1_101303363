const express = require("express")
const app = express()

// User Routes//
const userRoutes=require("./routes/user")
// Employee Routes//
const empRoutes=require("./routes/employee")
// 
const mongoose =require("mongoose")

//Connection of database and entering database's username and password
mongoose.connect("mongodb+srv://admin:2231874q@cluster0.i8p9yk7.mongodb.net/comp3123_assignment?retryWrites=true&w=majority",{
    useNewUrlParser: true,
    useUnifiedTopology: true
})

app.use(express.json())
// app.use(express.urlencoded())

// Port Number
const SERVER_PORT =3003

app.use("/api/",userRoutes)
app.use("/api/",empRoutes)
app.route("/")
    .get((req,res)=>{
        res.send("WEL - User")

    })

app.route("/api")
    .get((req,res)=>{
        res.send("Welcome Page")

    })





app.listen(SERVER_PORT,()=>{
    console.log("http://localhost:3003/")
})


/* 
api/user/signup
api/user/login

*/

